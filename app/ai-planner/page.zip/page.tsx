"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Send } from "lucide-react"

type Message = {
  sender: "ai" | "user"
  text: string
}

export default function AITripPlanner() {
  const [messages, setMessages] = useState<Message[]>([
    { sender: "ai", text: "👋 Hello traveler! I’m your AI trip buddy. Where would you like to go?" },
  ])
  const [input, setInput] = useState("")
  const [itinerary, setItinerary] = useState<string[]>([])
  const [isTyping, setIsTyping] = useState(false)

  const handleSend = () => {
    if (!input.trim()) return

    // Add user message
    setMessages((prev) => [...prev, { sender: "user", text: input }])
    const userQuery = input
    setInput("")
    setIsTyping(true)

    // Fake AI response with itinerary
    setTimeout(() => {
      setIsTyping(false)
      setMessages((prev) => [
        ...prev,
        { sender: "ai", text: `✨ Awesome! Planning your trip to ${userQuery}...` },
      ])

      // Fake Itinerary
      setItinerary([
        "Arrival & Old Town Walk",
        "Museums & Street Food",
        "Nature Day Trip",
        "Neighborhoods & Nightlife",
      ])
    }, 1500)
  }

  return (
    <div className="h-screen w-full flex bg-gradient-to-br from-gray-900 via-black to-gray-800 text-white relative overflow-hidden">
      {/* Background with animated glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.15),transparent_70%)] animate-pulse" />

      {/* Left panel - AI Avatar */}
      <div className="hidden md:flex w-1/4 flex-col items-center justify-center border-r border-gray-800 bg-black/40 backdrop-blur-md relative">
        <motion.div
          className="w-32 h-32 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-4xl shadow-lg"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ repeat: Infinity, duration: 3 }}
        >
          🤖
        </motion.div>
        <p className="mt-4 text-gray-400 text-center text-sm">Your AI Travel Buddy</p>
      </div>

      {/* Middle panel - Chat */}
      <div className="flex-1 flex flex-col z-10 h-[90%]">
        {/* Chat header */}
        <header className="p-4 text-center border-b border-gray-700">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            AI Trip Planner
          </h1>
          <p className="text-gray-400 text-sm">Plan smarter journeys with AI assistance</p>
        </header>

        {/* Chat messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-sm px-4 py-2 rounded-2xl ${
                  msg.sender === "user"
                    ? "bg-blue-600 text-white rounded-br-none"
                    : "bg-gray-800 text-gray-100 rounded-bl-none"
                }`}
              >
                {msg.text}
              </div>
            </motion.div>
          ))}

          {/* Typing dots */}
          {isTyping && (
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
              <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-150"></span>
              <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-300"></span>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="p-4 border-t border-gray-700 flex items-center space-x-2 bg-black/40 backdrop-blur-md">
          <input
            type="text"
            placeholder="Ask me about your trip..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            className="flex-1 px-4 py-2 rounded-full bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={handleSend}
            aria-label="Send message"
            className="p-3 rounded-full bg-blue-600 hover:bg-blue-700 transition"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Right panel - Itinerary */}
      <div className="hidden md:flex w-1/4 flex-col border-l border-gray-800 bg-black/40 backdrop-blur-md p-4 space-y-4 overflow-y-auto">
        <h2 className="text-lg font-semibold">Your Itinerary</h2>
        {itinerary.map((item, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.3 }}
            className="p-3 rounded-xl bg-gradient-to-r from-gray-800 to-gray-700 shadow-md hover:shadow-lg"
          >
            <span className="text-blue-400 font-semibold">Day {i + 1}:</span> {item}
          </motion.div>
        ))}
      </div>
    </div>
  )
}
